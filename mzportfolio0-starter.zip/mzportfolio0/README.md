# Mohammad Zuhar — Engineering & ICT Portfolio

A bilingual (English / Japanese) personal portfolio built with React, TypeScript and Vite. The visual direction uses a dark navy engineering aesthetic with restrained blue and cyan accents.

## Features

- English and Japanese content switcher
- Responsive navigation and layouts
- Sections for profile, technical interests, education, projects, voluntary experience, internship exposure, career direction and contact
- Clear distinction between completed academic work, prototypes, concepts and research interests
- Accessible semantic structure and reduced reliance on animation
- GitHub Pages-ready Vite configuration

## Run locally

Requirements: Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build

```bash
npm run build
npm run preview
```

## Deploy to GitHub Pages

The Vite base path is configured for this repository name: `/mzportfolio0/`.

1. In GitHub, open **Settings → Pages**.
2. Set the source to **GitHub Actions**.
3. Add a workflow at `.github/workflows/deploy.yml` (or use the workflow included in this repository).
4. Push changes to `main`; the workflow builds `dist` and deploys it to Pages.

## Personalise before sharing

- Replace the profile placeholder with `public/images/profile.jpg` and update the profile block in `src/App.tsx`.
- Add your actual CV files as `public/documents/english-cv.pdf` and `public/documents/japanese-cv.pdf`, then connect the CV links.
- Replace `YOUR_EMAIL@example.com` with your professional email.
- Replace the LinkedIn placeholder URL with your profile URL.
- Review project statuses and descriptions against the latest state of each project before sharing with recruiters.

## Project content

Portfolio text is maintained in `src/data/content.ts`. Update both `en` and `ja` entries when changing content.

## Notes

No unconfirmed achievements, email address, LinkedIn profile, CV files or project outcomes are fabricated. The Community Assistance Platform and AnatoLearn are presented as concepts / prototypes in development; update these labels only when their implementation status is verified.
