import { useState } from 'react'
import { ArrowDown, ArrowRight, ArrowUpRight, Cpu, CircuitBoard, Code2, Globe2, GraduationCap, Laptop, Linkedin, Mail, Menu, Network, RadioTower, Sparkles, X, BrainCircuit, Github, MapPin, ExternalLink } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { content, type Language } from './data/content'

const interestIcons: LucideIcon[] = [CircuitBoard, Globe2, Cpu, Code2, RadioTower, BrainCircuit, Network]

function App() {
  const [lang, setLang] = useState<Language>('en')
  const [menuOpen, setMenuOpen] = useState(false)
  const t = content[lang]
  const navItems = [
    ['about', t.nav.about], ['interests', t.nav.interests], ['education', t.nav.education],
    ['projects', t.nav.projects], ['experience', t.nav.experience], ['contact', t.nav.contact],
  ]
  const scrollTo = (id: string) => { document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); setMenuOpen(false) }

  return <div className="site-shell">
    <header className="topbar">
      <a className="brand" href="#home" aria-label="Mohammad Zuhar home"><span className="brand-mark">MZ</span><span>MOHAMMAD ZUHAR<span className="brand-sub">ENGINEERING & ICT</span></span></a>
      <nav className={menuOpen ? 'nav-links open' : 'nav-links'} aria-label="Main navigation">
        {navItems.map(([id, label]) => <button key={id} onClick={() => scrollTo(id)}>{label}</button>)}
      </nav>
      <div className="nav-actions"><div className="language-switch" aria-label="Choose language"><button className={lang === 'en' ? 'active' : ''} onClick={() => setLang('en')}>EN</button><span>/</span><button className={lang === 'ja' ? 'active' : ''} onClick={() => setLang('ja')}>日本語</button></div><button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X /> : <Menu />}</button></div>
    </header>

    <main>
      <section className="hero section-wrap" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" />{t.hero.eyebrow}</div>
          <h1>{t.hero.title}<span className="period">.</span></h1>
          <p className="hero-tagline">{t.hero.tagline}</p>
          <p className="hero-intro">{t.hero.intro}</p>
          <div className="hero-meta"><span><MapPin size={15}/>{t.hero.location}</span><span className="availability-dot">{t.hero.availability}</span></div>
          <div className="hero-buttons"><button className="button button-primary" onClick={() => scrollTo('projects')}>{t.hero.projects}<ArrowUpRight size={17}/></button><button className="button button-ghost" onClick={() => scrollTo('contact')}>{t.hero.contact}<ArrowRight size={16}/></button></div>
        </div>
        <div className="hero-visual" aria-label="Profile photo placeholder">
          <div className="visual-grid"/><div className="orbit orbit-one"/><div className="orbit orbit-two"/>
          <div className="profile-frame"><div className="profile-placeholder"><span className="profile-initials">MZ</span><span className="profile-label">PROFILE PHOTO</span></div></div>
          <div className="floating-chip chip-top"><Cpu size={16}/><span>ENGINEERING</span></div><div className="floating-chip chip-bottom"><Network size={16}/><span>CONNECTING IDEAS</span></div>
          <div className="visual-index">01 <span>—</span> 07</div>
        </div>
        <button className="scroll-cue" onClick={() => scrollTo('about')}><span>SCROLL TO EXPLORE</span><ArrowDown size={15}/></button>
      </section>

      <section className="section-wrap section-block" id="about"><div className="section-heading"><span className="section-kicker">01 / {t.about.label}</span><h2>{t.about.title}</h2></div><div className="about-layout"><div className="about-symbol"><span className="symbol-bracket">{`{`}</span><span className="symbol-core">MZ<span>_</span></span><span className="symbol-bracket">{`}`}</span><small>ENGINEERING MINDSET</small></div><div className="about-text"><p>{t.about.body}</p><p>{t.about.body2}</p><div className="note-line"><Sparkles size={17}/><span>{t.about.note}</span></div></div></div></section>

      <section className="section-band" id="interests"><div className="section-wrap section-block"><div className="section-heading"><span className="section-kicker">02 / {t.interests.label}</span><h2>{t.interests.title}</h2><p>{t.interests.subtitle}</p></div><div className="interest-grid">{t.interests.items.map((item, i) => { const Icon = interestIcons[i]; return <article className="interest-card" key={item[0]}><div className="interest-card-top"><span className="interest-icon"><Icon size={21}/></span><span className="card-number">0{i + 1}</span></div><h3>{item[0]}</h3><p>{item[1]}</p></article> })}</div></div></section>

      <section className="section-wrap section-block" id="education"><div className="section-heading"><span className="section-kicker">03 / {t.education.label}</span><h2>{t.education.title}</h2></div><div className="education-layout"><div className="timeline">{t.education.items.map((item) => <article className="timeline-item" key={item.school}><div className="timeline-marker"><GraduationCap size={18}/></div><div><span className="timeline-date">{item.date}</span><h3>{item.school}</h3><p className="degree">{item.degree}</p><span className="muted-line">{item.place}</span></div></article>)}</div><aside className="research-card"><span className="research-label">{t.education.research}</span><h3>{t.education.researchTitle}</h3><p>{t.education.researchText}</p><div className="research-icon"><BrainCircuit size={25}/></div></aside></div></section>

      <section className="section-band" id="projects"><div className="section-wrap section-block"><div className="section-heading"><span className="section-kicker">04 / {t.projects.label}</span><h2>{t.projects.title}</h2><p>{t.projects.subtitle}</p></div><div className="project-grid">{t.projects.items.map((project, i) => <article className="project-card" key={project.title}><div className={`project-art art-${i + 1}`}><span className="project-art-index">PROJECT / 0{i + 1}</span><div className="art-symbol">{i === 0 ? <Network/> : i === 1 ? <GraduationCap/> : i === 2 ? <BrainCircuit/> : <CircuitBoard/>}</div><span className="art-category">{project.category}</span></div><div className="project-content"><div className="project-status">{project.status}</div><h3>{project.title}</h3><p>{project.description}</p><div className="project-detail"><strong>{t.contribution}</strong><span>{project.contribution}</span></div><div className="tag-list">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div>{project.link && <a className="text-link" href={project.link} target="_blank" rel="noreferrer">{project.linkLabel}<ExternalLink size={14}/></a>}</div></article>)}</div></div></section>

      <section className="section-wrap section-block" id="experience"><div className="section-heading"><span className="section-kicker">05 / {t.experience.label}</span><h2>{t.experience.title}</h2></div><div className="experience-grid"><article className="experience-card volunteer-card"><div className="experience-icon"><Globe2 size={22}/></div><span className="experience-type">VOLUNTARY EXPERIENCE</span><h3>{t.experience.volunteer}</h3><h4>{t.experience.organisation}</h4><p>{t.experience.volunteerText}</p><ul>{t.experience.bullets.map(x => <li key={x}>{x}</li>)}</ul></article><article className="experience-card internship-card"><div className="experience-icon"><Laptop size={22}/></div><span className="experience-type">INTERNSHIP</span><h3>{t.experience.internship}</h3><h4>{t.experience.company}</h4><span className="muted-line">{t.experience.place}</span><p>{t.experience.internshipText}</p><div className="note-line"><Sparkles size={16}/><span>{t.experience.caveat}</span></div></article></div></section>

      <section className="career-band"><div className="section-wrap career-inner"><div><span className="section-kicker">06 / {t.direction.label}</span><h2>{t.direction.title}</h2></div><p>{t.direction.text}</p></div></section>

      <section className="section-wrap section-block contact-section" id="contact"><div className="contact-panel"><div className="contact-copy"><span className="section-kicker">07 / {t.contact.label}</span><h2>{t.contact.title}</h2><p>{t.contact.text}</p><p className="contact-placeholder">{t.contact.placeholder}</p></div><div className="contact-links"><a href="mailto:YOUR_EMAIL@example.com"><Mail size={18}/><span>{t.contact.email}</span><ArrowUpRight size={16}/></a><a href="https://github.com/mdzuhar-sk" target="_blank" rel="noreferrer"><Github size={18}/><span>{t.contact.github}</span><ArrowUpRight size={16}/></a><a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><Linkedin size={18}/><span>{t.contact.linkedin}</span><ArrowUpRight size={16}/></a><div className="cv-links"><span>{t.contact.cv}</span><span>{t.contact.jaCv}</span><small>CV files will be added here</small></div></div></div></section>
    </main>
    <footer className="footer"><div className="section-wrap footer-inner"><a className="brand" href="#home"><span className="brand-mark">MZ</span><span>MOHAMMAD ZUHAR<span className="brand-sub">ENGINEERING & ICT</span></span></a><span>© {new Date().getFullYear()} Mohammad Zuhar · {t.footer}</span><button onClick={() => scrollTo('home')}>BACK TO TOP ↑</button></div></footer>
  </div>
}

export default App
