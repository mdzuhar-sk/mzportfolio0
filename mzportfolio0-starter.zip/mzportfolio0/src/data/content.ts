export type Language = 'en' | 'ja'

export const content = {
  en: {
    nav: { about: 'About', interests: 'Interests', education: 'Education', projects: 'Projects', experience: 'Experience', contact: 'Contact' },
    hero: {
      eyebrow: 'ELECTRONICS · ICT · TECHNOLOGY',
      title: 'Mohammad Zuhar',
      tagline: 'Engineer. Innovator. Facilitator.',
      intro: 'An emerging engineering and ICT professional with a foundation in Electronic and Telecommunication Engineering and a growing focus on practical technology development.',
      location: 'Kobe, Japan',
      projects: 'Explore projects', cv: 'View CV', contact: 'Get in touch',
      availability: 'Open to learning, collaboration and engineering opportunities',
    },
    about: {
      label: 'A little about me', title: 'Connecting engineering with meaningful impact.',
      body: 'My academic journey began in Electronic and Telecommunication Engineering and continues through master’s studies in Information and Communication Technology at Kobe Institute of Computing, Japan. I am interested in how electronics, hardware, software and communication technologies can work together to solve practical problems.',
      body2: 'Alongside my technical interests, voluntary community engagement has shaped how I think about people, access and the real-world context in which technology is used. I value curiosity, steady learning and building things that are useful.',
      note: 'My interests are areas I am actively exploring and developing — not a claim of expertise in every field.',
    },
    interests: {
      label: 'What I explore', title: 'Technical interests',
      subtitle: 'A multidisciplinary foundation, with room to keep learning.',
      items: [
        ['Electronics', 'Electronic circuits, components and practical experimentation.'],
        ['ICT', 'Using information and communication technologies to address real needs.'],
        ['Hardware', 'Understanding devices, embedded platforms and physical systems.'],
        ['Software development', 'Building useful digital tools and learning through implementation.'],
        ['Telecommunications', 'Communication systems, connectivity and network technologies.'],
        ['AI & machine learning', 'Exploring data-driven methods and intelligent applications.'],
        ['Networking & systems', 'Computer networks, infrastructure and dependable systems.'],
      ],
    },
    education: {
      label: 'Academic background', title: 'Education',
      items: [
        { school: 'Kobe Institute of Computing (KIC)', place: 'Kobe, Japan', degree: 'Master’s studies in Information and Communication Technology', date: 'Currently enrolled' },
        { school: 'International Islamic University Chittagong (IIUC)', place: 'Bangladesh', degree: 'BSc in Electronic and Telecommunication Engineering', date: 'Undergraduate degree' },
      ],
      research: 'Undergraduate research', researchTitle: 'Machine Learning and Deep Learning for Anemia Disease Prediction', researchText: 'Explored predictive modelling approaches using health-related variables, including haemoglobin and red-cell indices.',
    },
    projects: {
      label: 'Selected work', title: 'Projects & research', subtitle: 'A mix of completed academic work, developing prototypes and research interests. Status is stated transparently.',
      items: [
        { title: 'Rohingya Community Assistance Platform', category: 'Community technology', status: 'Concept / in development', description: 'An offline-capable platform concept for organising access to community information, emergency guidance, health services and essential-service updates.', contribution: 'Independent concept development and feature planning, with privacy and safe communication as priorities.', tags: ['PWA concept', 'Offline-first', 'Community support'], link: '', linkLabel: '' },
        { title: 'AnatoLearn', category: 'Educational technology', status: 'Prototype / in development', description: 'An anatomy learning platform concept focused on visual explanations, structured lessons and quizzes for secondary-level learners.', contribution: 'Learning-content planning and development of an interactive learning experience.', tags: ['Web learning', '3D learning direction', 'Quizzes'], link: 'https://github.com/mdzuhar-sk/anatolearn', linkLabel: 'View GitHub' },
        { title: 'Machine Learning-Based Anemia Prediction', category: 'Undergraduate research', status: 'Completed academic research', description: 'Undergraduate research exploring machine learning and deep learning approaches to anemia disease prediction.', contribution: 'Academic research using features such as haemoglobin, age, gender and red-cell indices.', tags: ['Machine learning', 'Deep learning', 'Prediction'], link: '', linkLabel: '' },
        { title: 'Electronics & ICT-Supported Learning', category: 'Developing research interest', status: 'Research interest', description: 'Exploring how practical hardware activities and ICT-supported feedback might help learners understand introductory electronics.', contribution: 'Developing a feasible research direction around measurement-informed learning and practical circuit work.', tags: ['Electronics education', 'Hardware', 'Learning feedback'], link: '', linkLabel: '' },
      ],
    },
    experience: {
      label: 'People & practice', title: 'Voluntary experience & practical exposure',
      volunteer: 'Community engagement & facilitation', organisation: 'BRAC · Community-based voluntary activities',
      volunteerText: 'Contributed to community activities with a focus on participation, learning and communication. This experience strengthened my ability to work with people, collaborate with teams and understand community needs.',
      bullets: ['Encouraging community participation and engagement', 'Supporting educational and learning activities', 'Communicating with community members', 'Collaborating with teams and facilitating activities'],
      internship: 'Internship experience', company: 'SHIMA SEIKI MFG., LTD.', place: 'Wakayama, Japan · 24–28 August 2026',
      internshipText: 'Practical exposure to the company’s technology and manufacturing environment, including areas such as CAD, machine assembly, image processing and automated machinery.',
      caveat: 'Presented as exposure and learning; no independent technical achievements are implied.',
    },
    direction: { label: 'Looking ahead', title: 'Career direction', text: 'I aim to continue developing my engineering and ICT capabilities and build a career in Japan, contributing to practical technology development across electronics, hardware, telecommunications and connected systems.' },
    contact: { label: 'Let’s connect', title: 'Have a project, opportunity or idea?', text: 'I welcome thoughtful conversations, learning opportunities and collaboration related to engineering and ICT.', email: 'Email', github: 'GitHub', linkedin: 'LinkedIn', cv: 'English CV', jaCv: 'Japanese CV', placeholder: 'Add your professional email and LinkedIn URL here.' },
    footer: 'Designed and developed with curiosity.',
    status: 'Status', contribution: 'My contribution', technologies: 'Focus areas',
  },
  ja: {
    nav: { about: '自己紹介', interests: '技術分野', education: '学歴', projects: 'プロジェクト', experience: '経験', contact: 'お問い合わせ' },
    hero: {
      eyebrow: '電子工学 · ICT · テクノロジー', title: 'Mohammad Zuhar', tagline: 'Engineer. Innovator. Facilitator.',
      intro: '電子・通信工学を基礎とし、実践的な技術開発に関心を持つ、成長を続けるエンジニアリング・ICT分野の人材です。',
      location: '日本・神戸', projects: 'プロジェクトを見る', cv: '履歴書を見る', contact: 'お問い合わせ',
      availability: '学び・協働・エンジニアリング分野の機会に関心があります',
    },
    about: {
      label: 'プロフィール', title: '工学を、社会に役立つ技術へ。',
      body: '私の学びは電子・通信工学から始まり、現在は日本の神戸情報大学院大学で情報通信技術（ICT）を学んでいます。電子工学、ハードウェア、ソフトウェア、通信技術を組み合わせ、実際の課題解決につなげることに関心があります。',
      body2: '技術分野への関心に加え、ボランティアとしての地域活動を通じて、人々のニーズや技術へのアクセス、実際の利用環境について考えるようになりました。好奇心を持ち、継続して学び、役立つものを形にすることを大切にしています。',
      note: 'ここに記載している分野は、現在学び、理解を深めている関心領域です。すべての分野における専門性を示すものではありません。',
    },
    interests: {
      label: '関心のある分野', title: '技術分野', subtitle: '幅広い工学の基礎を活かしながら、学びを深めています。',
      items: [
        ['電子工学', '電子回路、電子部品、実践的な実験への関心。'],
        ['ICT', '情報通信技術を活用した課題解決への関心。'],
        ['ハードウェア', 'デバイス、組込みプラットフォーム、物理システムへの関心。'],
        ['ソフトウェア開発', '実装を通じた実用的なデジタルツールの開発。'],
        ['通信工学', '通信システム、接続性、ネットワーク技術への関心。'],
        ['AI・機械学習', 'データに基づく手法と知的なアプリケーションの探究。'],
        ['ネットワーク・システム', 'コンピュータネットワーク、基盤技術、安定したシステムへの関心。'],
      ],
    },
    education: {
      label: '学術的背景', title: '学歴',
      items: [
        { school: '神戸情報大学院大学（KIC）', place: '日本・神戸', degree: '情報通信技術（ICT）分野 修士課程', date: '在学中' },
        { school: 'International Islamic University Chittagong（IIUC）', place: 'バングラデシュ', degree: '電子・通信工学 学士', date: '学士課程修了' },
      ],
      research: '学部研究', researchTitle: '貧血症予測のための機械学習・深層学習', researchText: 'ヘモグロビン値や赤血球関連指標などの健康関連データを用いた予測モデルの手法を検討しました。',
    },
    projects: {
      label: '取り組み', title: 'プロジェクト・研究', subtitle: '学部研究、開発中のプロトタイプ、今後深めたい研究テーマを、現状に合わせて紹介します。',
      items: [
        { title: 'ロヒンギャ・コミュニティ支援プラットフォーム', category: 'コミュニティ向け技術', status: '構想・開発中', description: '地域情報、緊急時の案内、医療サービス、生活に必要なサービス情報へのアクセスを整理する、オフライン対応を想定したプラットフォーム構想です。', contribution: 'プライバシーと安全な情報共有を重視した、個人での構想・機能設計。', tags: ['PWA構想', 'オフライン対応', '地域支援'], link: '', linkLabel: '' },
        { title: 'AnatoLearn', category: '教育テクノロジー', status: 'プロトタイプ・開発中', description: '視覚的な解説、体系的なレッスン、クイズを通じて、中高生の解剖学学習を支援することを目指す学習プラットフォームです。', contribution: '学習コンテンツの企画と、インタラクティブな学習体験の開発。', tags: ['Web学習', '3D学習の方向性', 'クイズ'], link: 'https://github.com/mdzuhar-sk/anatolearn', linkLabel: 'GitHubを見る' },
        { title: '機械学習による貧血症予測', category: '学部研究', status: '学部研究・完了', description: '機械学習および深層学習を用いた貧血症予測の手法を検討した学部研究です。', contribution: 'ヘモグロビン値、年齢、性別、赤血球関連指標などを用いた学術研究。', tags: ['機械学習', '深層学習', '予測'], link: '', linkLabel: '' },
        { title: '電子工学学習とICT支援', category: '研究関心', status: '研究テーマを検討中', description: '実践的なハードウェア活動とICTによるフィードバックが、基礎電子工学の理解をどのように支援できるかを探究しています。', contribution: '測定結果に基づく学習支援と回路実習を軸に、実現可能な研究方向を検討。', tags: ['電子工学教育', 'ハードウェア', '学習フィードバック'], link: '', linkLabel: '' },
      ],
    },
    experience: {
      label: '人との協働・実践', title: 'ボランティア活動・実務体験',
      volunteer: '地域活動・ファシリテーション', organisation: 'BRAC · 地域におけるボランティア活動',
      volunteerText: '参加、学び、コミュニケーションを重視した地域活動に携わりました。この経験を通じて、人々と協力する力、チームワーク、地域のニーズを理解する姿勢を身につけました。',
      bullets: ['地域の人々の参加・交流を促進', '教育・学習活動の支援', '地域住民とのコミュニケーション', 'チームとの協働および活動の進行支援'],
      internship: 'インターンシップ', company: 'SHIMA SEIKI MFG., LTD.', place: '日本・和歌山県 · 2026年8月24日〜28日',
      internshipText: '企業の技術・製造環境に触れ、CAD、機械組立、画像処理、自動機械などの分野について学ぶ機会を得ました。',
      caveat: '技術分野への理解を深めるための実習・見学経験として記載しており、個人で達成した技術成果を示すものではありません。',
    },
    direction: { label: 'これからの目標', title: 'キャリアの方向性', text: 'エンジニアリングとICTの知識・技術を継続して高め、日本でキャリアを築きながら、電子工学、ハードウェア、通信、ネットワーク技術などを通じた実践的な技術開発に貢献したいと考えています。' },
    contact: { label: 'つながりましょう', title: 'プロジェクト・機会・アイデアについて', text: 'エンジニアリングやICTに関する対話、学びの機会、協働を歓迎します。', email: 'メール', github: 'GitHub', linkedin: 'LinkedIn', cv: '英語CV', jaCv: '日本語履歴書', placeholder: 'ここに連絡用メールアドレスとLinkedIn URLを設定してください。' },
    footer: '好奇心を持って設計・開発しています。', status: '状況', contribution: '担当・取り組み', technologies: '関連分野',
  },
} as const
