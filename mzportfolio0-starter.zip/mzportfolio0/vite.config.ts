import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// GitHub Pages project-site path. Update this if the repository name changes.
export default defineConfig({
  plugins: [react()],
  base: '/mzportfolio0/',
})
